module.exports = [
  {
    id: 1,
    img: "/img/team/boris.jpg",
    name: "CTO",
    designation: "Full stack developer",
  },
  {
    id: 2,
    img: "/img/team/boris.jpg",
    name: "CTO",

    designation: "Full stack developer",
  },
  {
    id: 3,
    img: "/img/team/boris.jpg",
    name: "CTO",
    designation: "Full stack developer",
  },
  {
    id: 4,
    img: "/img/team/boris.jpg",
    name: "CTO",
    designation: "Full stack developer",
  },
  {
    id: 5,
    img: "/img/team/boris.jpg",
    name: "CTO",
    designation: "Full stack developer",
  },
  {
    id: 6,
    img: "/img/team/boris.jpg",
    name: "CTO",
    designation: "Full stack developer",
  },
];
