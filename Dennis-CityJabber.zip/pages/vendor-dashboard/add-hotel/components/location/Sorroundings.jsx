const Sorroundings = () => {
  return (
    <div className="row x-gap-20 y-gap-20">
      <div className="col-12">
        <div className="form-input ">
          <input type="text" required />
          <label className="lh-1 text-16 text-light-1">
            Hotel rating standard
          </label>
        </div>
      </div>
    </div>
  );
};

export default Sorroundings;
