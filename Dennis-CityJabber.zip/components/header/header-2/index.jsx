import Link from "next/link";
import { useEffect, useState } from "react";
import Modal from "react-bootstrap/Modal";
import CurrenctyMegaMenu from "../CurrenctyMegaMenu";
import LanguageMegaMenu from "../LanguageMegaMenu";
// import LocationSearch from "./LocationSearch";
import MobileMenu from "../MobileMenu";
import LoginForm from "../../../components/common/LoginForm";
import LoginWithSocial from "../../../components/common/LoginWithSocial";
import SignUpForm from "../../common/SignUpForm";
import HeaderSearch from "../HeaderSearch";

const Header1 = () => {
  const [navbar, setNavbar] = useState(false);
  const [show, setshow] = useState(false);
  const [signupShow, setSignupShow] = useState(false);
  const [byEmail, setByEmail] = useState(false);

  const handleClose = () => {
    setSignupShow(false);
    setshow(false);
    setByEmail(false);
  };
  const handleShow = () => {
    setshow(true);
    setSignupShow(false);
  };

  const handleSignupShow = () => {
    setSignupShow(true);
    setshow(false);
  };

  const changeBackground = () => {
    if (window.scrollY >= 10) {
      setNavbar(true);
    } else {
      setNavbar(false);
    }
  };

  useEffect(() => {
    window.addEventListener("scroll", changeBackground);
  }, []);

  return (
    <>
      <header className={`header ${navbar ? "bg-dark-1 is-sticky" : ""}`}>
        <div className="header__container container">
          <div className="row justify-between items-center">
            <div className="col-auto mobile-col">
              <div className="d-flex items-center">
                <div className="mr-20 d-flex items-center">
                  <div className="mr-15 d-none md:d-flex">
                    <Link
                      href="/others-pages/login"
                      className="icon-user text-inherit text-22 text-white"
                    />
                  </div>
                  {/* End mobile menu icon */}

                  <button
                    className="d-flex items-center icon-menu text-white text-20"
                    data-bs-toggle="offcanvas"
                    aria-controls="mobile-sidebar_menu"
                    data-bs-target="#mobile-sidebar_menu"
                  ></button>
                  <div
                    className="offcanvas offcanvas-start  mobile_menu-contnet"
                    tabIndex="-1"
                    id="mobile-sidebar_menu"
                    aria-labelledby="offcanvasMenuLabel"
                    data-bs-scroll="true"
                  >
                    <MobileMenu />
                  </div>
                </div>
                {/* End mobile humberger menu */}

                <Link href="/" className="header-logo mr-20">
                  <img src="/img/general/logo-light-2.svg" alt="logo icon" />
                  <img src="/img/general/logo-dark.svg" alt="logo icon" />
                </Link>
                <HeaderSearch />
                {/* End logo */}

                {/* <div className="relative xl:d-none">
                  <LocationSearch />
                </div> */}
                {/* End Search box */}
              </div>
              {/* End d-flex */}
            </div>
            {/* End col */}

            <div className="col-auto">
              <div className="d-flex items-center">
                <div className="row x-gap-20 items-center xxl:d-none">
                  <CurrenctyMegaMenu textClass="text-white" />
                  {/* End Megamenu for Currencty */}

                  {/* Start vertical devider*/}
                  <div className="col-auto">
                    <div className="w-1 h-20 bg-white-20" />
                  </div>
                  {/* End vertical devider*/}

                  <LanguageMegaMenu textClass="text-white" />
                  {/* End Megamenu for Language */}
                </div>
                {/* End language and currency selector */}

                {/* Start btn-group */}
                <div className="d-flex items-center ml-20 is-menu-opened-hide md:d-none">
                  {/* <Link
                    href="/others-pages/login"
                    className="button px-30 fw-400 text-14 -white bg-white h-50 text-dark-1"
                  >
                    Become An Expert
                  </Link> */}

                  {/* <Link
                    // href="/others-pages/signup"
                    className="button px-30 fw-400 text-14 border-white -outline-white h-50 text-white ml-20"
                  >
                    Sign In / Register
                  </Link> */}

                  <div
                    onClick={handleShow}
                    className="button px-30 fw-400 text-14 border-white -outline-white h-50 text-white ml-20"
                    role="button"
                  >
                    Sign In / Register
                  </div>
                </div>
                {/* End btn-group */}
              </div>
            </div>
            {/* End col-auto */}
          </div>
          {/* End .row */}
        </div>
        {/* End header_container */}
      </header>

      {/* Login Modal */}
      <Modal
        show={show}
        onHide={handleClose}
        className="d-flex align-items-center justify-content-center "
      >
        <Modal.Header closeButton>
          <Modal.Title>
            <h1 className="text-22 fw-500">Welcome back</h1>
          </Modal.Title>
        </Modal.Header>
        <Modal.Body>
          <LoginForm byEmail={byEmail} setByEmail={setByEmail} />
          {/* End .Login */}
          {!byEmail && (
            <div className="row y-gap-20 pt-30">
              <div className="col-12">
                <div className="text-center">or sign in with</div>
              </div>
              <LoginWithSocial />
            </div>
          )}
          <div className="col-12 text-center">
            <p className="mt-10">
              Don&apos;t have an account yet?{" "}
              <span
                className="text-blue-1 "
                style={{ cursor: "pointer" }}
                onClick={handleSignupShow}
              >
                Sign up for free
              </span>
            </p>
          </div>
          {/* End .row */}
        </Modal.Body>
        <Modal.Footer>
          <div className="col-12">
            <div className="text-center px-10">
              By creating an account, you agree to our Terms of Service and
              Privacy Statement.
            </div>
          </div>
        </Modal.Footer>
      </Modal>

      {/* Signup Modal */}
      <Modal
        show={signupShow}
        onHide={handleClose}
        className="d-flex align-items-center justify-content-center "
        // size="lg"
      >
        <Modal.Header closeButton>
          <Modal.Title>
            <h1 className="text-22 fw-500">Welcome to Signup</h1>
          </Modal.Title>
        </Modal.Header>
        <Modal.Body>
          <SignUpForm
            byEmail={byEmail}
            setByEmail={setByEmail}
            handleShow={handleShow}
          />
        </Modal.Body>
        <Modal.Footer>
          <div className="col-12">
            <div className="text-center px-10">
              By creating an account, you agree to our Terms of Service and
              Privacy Statement.
            </div>
          </div>
        </Modal.Footer>
      </Modal>
    </>
  );
};

export default Header1;
